const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const cors = require('cors');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/authRoutes');
const studentRoutes = require('./routes/studentRoutes');

const app = express();

// Middleware
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));
app.use(bodyParser.json());

// Session Setup
app.use(session({
  secret: 'secretKey123',
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: 'mongodb://localhost:27017/fullstackdb' }),
  cookie: { maxAge: 1000 * 60 * 60 } // 1 hour
}));

// Connect MongoDB
mongoose.connect('mongodb://localhost:27017/fullstackdb')
  .then(() => console.log('✅ MongoDB Connected'))
  .catch(err => console.log(err));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/students', studentRoutes);

app.listen(5000, () => console.log('🚀 Backend running on port 5000'));
