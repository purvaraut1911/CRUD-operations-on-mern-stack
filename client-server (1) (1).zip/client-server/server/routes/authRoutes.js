const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    const existing = await User.findOne({ username });
    if (existing) return res.json({ success: false, message: 'User exists' });

    const user = new User({ username, password });
    await user.save();
    res.json({ success: true, message: 'User registered' });
  } catch (err) {
    res.json({ success: false, message: 'Error registering' });
  }
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user) return res.json({ success: false, message: 'User not found' });

  const match = await user.comparePassword(password);
  if (!match) return res.json({ success: false, message: 'Incorrect password' });

  req.session.user = { id: user._id, username: user.username };
  res.json({ success: true, message: 'Login successful', user: req.session.user });
});

router.get('/logout', (req, res) => {
  req.session.destroy(() => res.json({ success: true, message: 'Logged out' }));
});

router.get('/check', (req, res) => {
  if (req.session.user) res.json({ loggedIn: true, user: req.session.user });
  else res.json({ loggedIn: false });
});

module.exports = router;
