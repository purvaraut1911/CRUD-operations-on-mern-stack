const express = require('express');
const router = express.Router();
const Student = require('../models/Student');

function isAuth(req, res, next) {
  if (req.session.user) return next();
  res.status(401).json({ message: 'Unauthorized' });
}

router.get('/', isAuth, async (req, res) => {
  const students = await Student.find();
  res.json(students);
});

router.post('/', isAuth, async (req, res) => {
  const { name, age, course } = req.body;
  const stu = new Student({ name, age, course });
  await stu.save();
  res.json({ success: true });
});

router.put('/:id', isAuth, async (req, res) => {
  const { name, age, course } = req.body;
  await Student.findByIdAndUpdate(req.params.id, { name, age, course });
  res.json({ success: true });
});

router.get('/:id', isAuth, async (req, res) => {
  
  const s=await Student.findById(req.params.id);
  if(!s){
    return res.status(404).json({message:"Student not found"});
  }
  res.json({ success: true, student: s });
});

router.delete('/:id', isAuth, async (req, res) => {
  await Student.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

module.exports = router;
