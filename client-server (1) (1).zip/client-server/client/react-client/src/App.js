import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import StudentList from './components/StudentList';
import AddStudent from './components/AddStudent';
import EditStudent from './components/EditStudent';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/students" element={ <ProtectedRoute>
    <StudentList />
  </ProtectedRoute>} />
        <Route path="/add" element={ <ProtectedRoute>
    <AddStudent />
  </ProtectedRoute>} />
        <Route path="/edit/:id" element={  <ProtectedRoute>
    <EditStudent />
  </ProtectedRoute>
} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
