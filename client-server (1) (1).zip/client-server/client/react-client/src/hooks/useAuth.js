import { useEffect, useState } from "react";
import api from "../api";

export default function useAuth() {
  const [loading, setLoading] = useState(true);
  const [loggedIn, setLoggedIn] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    api.get("/auth/check")
      .then(res => {
        setLoggedIn(res.data.loggedIn);
        setUser(res.data.user || null);
        setLoading(false);
      })
      .catch(() => {
        setLoggedIn(false);
        setLoading(false);
      });
  }, []);

  return { loading, loggedIn, user };
}
