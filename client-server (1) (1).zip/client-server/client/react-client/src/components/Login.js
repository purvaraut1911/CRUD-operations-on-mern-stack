import React, { useState } from "react";
import api from "../api";

export default function Login() {
  const [form, setForm] = useState({ username: "", password: "" });
  const [msg, setMsg] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await api.post("/auth/login", form);
    if (res.data.success) {
      window.location.href = "/students"; // redirect after login
    } else {
      setMsg(res.data.message);
    }
    // if (res.data.success) window.location.href = "/students";
    // else setMsg(res.data.message);
  };

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input
          placeholder="Username"
          onChange={(e) => setForm({ ...form, username: e.target.value })}
        />
        <input
          type="password"
          placeholder="Password"
          onChange={(e) => setForm({ ...form, password: e.target.value })}
        />
        <button>Login</button>
      </form>
      <p style={{ color: "red" }}>{msg}</p>
      <a href="/register">Register</a>
    </div>
  );
}
