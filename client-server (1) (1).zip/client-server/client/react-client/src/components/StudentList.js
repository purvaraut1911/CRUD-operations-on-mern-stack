import  { useEffect, useState } from 'react';
import api from '../api';
import { Link } from 'react-router-dom';

export default function StudentList() {
  const [students, setStudents] = useState([]);

useEffect(() => {
  api.get("/auth/check")
    .then(res => {
      if (!res.data.loggedIn) {
        window.location.href = "/";
      }
    });

  api.get("/students")
    .then(res => setStudents(res.data));
}, []);

  useEffect(() => {
    api.get('/students')
      .then(res => setStudents(res.data))
      .catch(() => window.location.href = '/');
  }, []);

  const deleteStudent = async (id) => {
    if(window.confirm("Are you sure you want to delete this student?"))
    {
    await api.delete(`/students/${id}`);
    setStudents(students.filter(s => s._id !== id));
    }
  };

  return (
    <div>
      <h2>Students</h2>
      <Link to="/add">Add Student</Link>
      <table border="1">
        <thead><tr><th>Name</th><th>Age</th><th>Course</th><th>Actions</th></tr></thead>
        <tbody>
          {students.map(s => (
            <tr key={s._id}>
              <td>{s.name}</td>
              <td>{s.age}</td>
              <td>{s.course}</td>
              <td>
                <Link to={`/edit/${s._id}`}>Edit</Link> |
                <button onClick={() => deleteStudent(s._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
