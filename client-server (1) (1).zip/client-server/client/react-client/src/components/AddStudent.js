import React, { useState } from 'react';
import api from '../api';

export default function AddStudent() {
  const [form, setForm] = useState({ name: '', age: '', course: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await api.post('/students', form);
    window.location.href = '/students';
  };

  return (
    <div>
      <h2>Add Student</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Name" onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input placeholder="Age" onChange={(e) => setForm({ ...form, age: e.target.value })} />
        <input placeholder="Course" onChange={(e) => setForm({ ...form, course: e.target.value })} />
        <button>Save</button>
      </form>
    </div>
  );
}
