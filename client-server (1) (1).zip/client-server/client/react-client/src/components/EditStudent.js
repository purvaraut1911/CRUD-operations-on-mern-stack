import React, { useEffect, useState } from 'react';
import api from '../api';
import { useParams } from 'react-router-dom';

export default function EditStudent() {
  const { id } = useParams();
  const [form, setForm] = useState({ name: '', age: '', course: '' });
  const [msg, setMsg] = useState("");

  useEffect(() => {
    api.get(`/students/${id}`)
      .then(res => {
        const stu = res.data.success ? res.data.student : setMsg("Student not found");
        setForm(stu);
      });
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await api.put(`/students/${id}`, form);
    window.location.href = '/students';
  };

  return (
    <div>
      <h2>Edit Student</h2>
      <form onSubmit={handleSubmit}>
        <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input value={form.age} onChange={(e) => setForm({ ...form, age: e.target.value })} />
        <input value={form.course} onChange={(e) => setForm({ ...form, course: e.target.value })} />
        <button>Update</button>
      </form>
      <p style={{color:"red"}}>{msg}</p>
    </div>
  );
}
