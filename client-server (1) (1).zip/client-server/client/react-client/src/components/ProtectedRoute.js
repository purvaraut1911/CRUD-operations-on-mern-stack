import useAuth from "../hooks/useAuth";
import { Navigate } from "react-router-dom";

export default function ProtectedRoute({ children }) {
  const { loading, loggedIn } = useAuth();

  if (loading) return <h2>Checking Authentication...</h2>;

  if (!loggedIn) return <Navigate to="/" replace />;

  return children;
}
