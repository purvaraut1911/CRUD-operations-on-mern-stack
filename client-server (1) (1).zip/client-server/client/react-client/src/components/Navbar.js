import React from "react";
import { Link } from "react-router-dom";
import useAuth from "../hooks/useAuth";
import api from "../api";

export default function Navbar() {
  const { loading, loggedIn, user } = useAuth();

  const logout = async () => {
    await api.get("/auth/logout");
    window.location.href = "/";
  };

  if (loading) return null;

  // If not logged in → hide menu
  if (!loggedIn) return null;

  return (
    <nav style={{ marginBottom: "20px" }}>
      <b>Welcome, {user.username}</b> |
      <Link to="/students"> Students </Link> |
      <Link to="/add"> Add Student </Link> |
      <button onClick={logout}>Logout</button>
    </nav>
  );
}
